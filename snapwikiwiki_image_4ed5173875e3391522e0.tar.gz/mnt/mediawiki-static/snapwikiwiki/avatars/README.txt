==Avatar Notes==
Please create an avatar directory under the path for images used in your MediaWiki Installaion.  This directory should be writeable.

Copy the 4 default images into the folder.  If a user does not have an avatar, these images will show up.